#!/bin/sh
ls svn/snp_env/deploy/lib/python2.6/encodings > /dev/null # don't worry about stdout
