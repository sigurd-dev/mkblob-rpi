/* Our second set comes from the i386 files.  */
#include "../errnoent.h"
